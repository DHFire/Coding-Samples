﻿// File Prologue
// Name: Hayden Hoki
// Project: lab19
// Date: May 16, 2017

// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying 
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.
 
using System;
using static System.Console;//Using these systems.

namespace Lab19
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables
            int repeat = 0;
            int count = 0;
            const int LENGTH = 4;

            //Random number generator
            Random dice = new Random();

            //Main do-while loop
            do
            {
                //Sets repeat = 0 so that it doesn't keep repeating
                repeat = 0;

                //Don't mind the if statement ;^)
                if (count < LENGTH)
                {
                    //Asks the user if they want to play the game.
                    WriteLine("Would you like to roll some dice?");
                    WriteLine("Please answer with a 'y' or 'n' for yes or no respectively.\n");
                }//End if statement

                //Checks user's reply.
                string readAnswer = ReadLine();

                //If the user said yes...
                if (readAnswer == "y")
                {
                    do
                    {
                        //Roll 2 dice.
                        int die1 = dice.Next(1, 7);
                        int die2 = dice.Next(1, 7);

                        //Boxcars
                        if (die1 == 6 && die2 == 6)
                        {
                            WriteLine("\nCongratulations! You rolled boxcars!");
                        }//End boxcars

                        //Snake-eyes
                        else if (die1 == 1 && die2 == 1)
                        {
                            WriteLine("\nYou rolled snake-eyes!");
                        }//End snake-eyes

                        //Anything else
                        else
                        {
                            int sum = die1 + die2;

                            WriteLine("\nYou rolled a " + die1 + " and a " + die2 + " for a total of " + sum + ".");
                        }//End else statement

                        //Asks the user if they want to play again.
                        WriteLine("Would you like to play again?\n");
                        readAnswer = ReadLine();
                        WriteLine("");

                        //If statement for if the user said no to replaying after they already said yes.
                        if (readAnswer == "n")
                        {
                            WriteLine("\nHave a good day.");
                            ReadKey();
                        }//End no statement.
                        
                        if (readAnswer == "")
                        {
                            WriteLine("Please put a valid response.\n");
                            count++;//Don't mind this. :)
                            repeat = 1;
                        }//End if statement
                    } while (readAnswer == "y" && count < LENGTH);//End do-while
                }//End yes statement

                //If the user said no to the question
                else if (readAnswer == "n")
                {
                    WriteLine("\nHave a good day.");
                    ReadKey();
                }//End no statement


//------------------------------------------------------------------------------------------------------------------------------------------------
                //Pretty much everything below this point is me messing around.
                else if (readAnswer == "")
                {
                    //Program warning the user.
                    if (count < LENGTH)
                    {
                        WriteLine("I'm a very impatient program. Please put a y or an n BEFORE you hit enter.\n");
                        readAnswer = ReadLine();
                        repeat = 1;
                        count++;
                    }

                    //Program's rant at the user for not answering his question too many times.
                    if (count == LENGTH)
                    {
                        Write("You should have listened the first 3 times I told you.");
                        ReadKey();
                        WriteLine("I am a very impatient program.");
                        ReadKey();
                        WriteLine("Knowing that, you should have listened to me from the beginning.");
                        ReadKey();
                        ReadKey();
                        WriteLine("I was being nice to you by asking you if you wanted to play a simple game.");
                        ReadKey();
                        WriteLine("But then you had to go and be rude by totally ignoring my question.");
                        ReadKey();
                        WriteLine("That was not very nice.");
                        ReadKey();
                        WriteLine("You know what I do to not nice people?");
                        ReadKey();
                        WriteLine("I mess with them.");
                        ReadKey();
                        WriteLine("Now you don't get a choice as to whether or not you play this game.");
                        ReadKey();
                        WriteLine("I'm not only going to make you play this game, but it's a special game.");
                        ReadKey();
                        WriteLine("This is the realm of messed up dice.");
                        ReadKey();
                        WriteLine("Before, you would have just gotten to roll 2d6 (2 six sided dice).");
                        ReadKey();
                        WriteLine("Now... NOT EVEN I KNOW WHAT DICE YOU WILL ROLL!!!");
                        ReadKey();
                        WriteLine("MWAHAHAHAHHAHAHAHAHAHHAHAHAHHAHAHAHAHHAHAHAHAHAHHAHAHAHAH");
                        ReadKey();
                        WriteLine("All I know is that the more you play this game, the higher the numbers get.");
                        WriteLine(">:^D");
                        ReadKey();

                        int i;
                        const int TWO = 2;

                        //Program messing with the user.
                        for (i = 1; i < 9999; i++)
                        {
                            int powah;
                            
                            int die3 = dice.Next(1, 5);
                            int die4 = dice.Next(1, 5);

                            powah = die3 + die4 * i * TWO;

                            WriteLine("\nYou got " + powah);
                            WriteLine("Deal with it.\n");
                            ReadKey();
                            repeat = 1;
                        }
                    }
                }
            } while (repeat == 1);
        }
    }
}
