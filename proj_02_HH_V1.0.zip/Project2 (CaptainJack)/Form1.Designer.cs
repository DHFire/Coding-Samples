﻿namespace Project2__CaptainJack_
{
    partial class CaptainJacksGold
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CaptainJacksGold));
            this.buttonSplitGold = new System.Windows.Forms.Button();
            this.textBoxGold = new System.Windows.Forms.TextBox();
            this.textBoxPirates = new System.Windows.Forms.TextBox();
            this.textBoxCaptainJack = new System.Windows.Forms.TextBox();
            this.textBoxFirstMate = new System.Windows.Forms.TextBox();
            this.textBoxCrew = new System.Windows.Forms.TextBox();
            this.textBoxPBF = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxCelebrate = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonSplitGold
            // 
            this.buttonSplitGold.Location = new System.Drawing.Point(146, 98);
            this.buttonSplitGold.Name = "buttonSplitGold";
            this.buttonSplitGold.Size = new System.Drawing.Size(198, 30);
            this.buttonSplitGold.TabIndex = 0;
            this.buttonSplitGold.Text = "Split Gold";
            this.buttonSplitGold.UseVisualStyleBackColor = true;
            this.buttonSplitGold.Click += new System.EventHandler(this.buttonSplitGold_Click);
            // 
            // textBoxGold
            // 
            this.textBoxGold.Location = new System.Drawing.Point(405, 37);
            this.textBoxGold.Name = "textBoxGold";
            this.textBoxGold.Size = new System.Drawing.Size(100, 22);
            this.textBoxGold.TabIndex = 1;
            // 
            // textBoxPirates
            // 
            this.textBoxPirates.Location = new System.Drawing.Point(405, 65);
            this.textBoxPirates.Name = "textBoxPirates";
            this.textBoxPirates.Size = new System.Drawing.Size(100, 22);
            this.textBoxPirates.TabIndex = 2;
            // 
            // textBoxCaptainJack
            // 
            this.textBoxCaptainJack.Location = new System.Drawing.Point(405, 173);
            this.textBoxCaptainJack.Name = "textBoxCaptainJack";
            this.textBoxCaptainJack.ReadOnly = true;
            this.textBoxCaptainJack.Size = new System.Drawing.Size(100, 22);
            this.textBoxCaptainJack.TabIndex = 3;
            // 
            // textBoxFirstMate
            // 
            this.textBoxFirstMate.Location = new System.Drawing.Point(405, 202);
            this.textBoxFirstMate.Name = "textBoxFirstMate";
            this.textBoxFirstMate.ReadOnly = true;
            this.textBoxFirstMate.Size = new System.Drawing.Size(100, 22);
            this.textBoxFirstMate.TabIndex = 4;
            // 
            // textBoxCrew
            // 
            this.textBoxCrew.Location = new System.Drawing.Point(405, 231);
            this.textBoxCrew.Name = "textBoxCrew";
            this.textBoxCrew.ReadOnly = true;
            this.textBoxCrew.Size = new System.Drawing.Size(100, 22);
            this.textBoxCrew.TabIndex = 5;
            // 
            // textBoxPBF
            // 
            this.textBoxPBF.Location = new System.Drawing.Point(405, 260);
            this.textBoxPBF.Name = "textBoxPBF";
            this.textBoxPBF.ReadOnly = true;
            this.textBoxPBF.Size = new System.Drawing.Size(100, 22);
            this.textBoxPBF.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Gold Found:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "# of Pirates:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Captian Jack Share:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "1st Mate Share:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Crew Share:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 261);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Pirate Benevolent Fund:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 317);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(495, 276);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(519, 28);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem1});
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(45, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(125, 26);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(125, 26);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // textBoxCelebrate
            // 
            this.textBoxCelebrate.Location = new System.Drawing.Point(405, 145);
            this.textBoxCelebrate.Name = "textBoxCelebrate";
            this.textBoxCelebrate.ReadOnly = true;
            this.textBoxCelebrate.Size = new System.Drawing.Size(100, 22);
            this.textBoxCelebrate.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(159, 17);
            this.label7.TabIndex = 16;
            this.label7.Text = "Celebration Gold Spent:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(519, 599);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxCelebrate);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxPBF);
            this.Controls.Add(this.textBoxCrew);
            this.Controls.Add(this.textBoxFirstMate);
            this.Controls.Add(this.textBoxCaptainJack);
            this.Controls.Add(this.textBoxPirates);
            this.Controls.Add(this.textBoxGold);
            this.Controls.Add(this.buttonSplitGold);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSplitGold;
        private System.Windows.Forms.TextBox textBoxGold;
        private System.Windows.Forms.TextBox textBoxPirates;
        private System.Windows.Forms.TextBox textBoxCaptainJack;
        private System.Windows.Forms.TextBox textBoxFirstMate;
        private System.Windows.Forms.TextBox textBoxCrew;
        private System.Windows.Forms.TextBox textBoxPBF;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.TextBox textBoxCelebrate;
        private System.Windows.Forms.Label label7;
    }
}

