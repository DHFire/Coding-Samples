﻿// File Prologue
// Name: Hayden Hoki
// Project: Project 2
// Date: February 14, 2017

// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying 
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

using System;
using System.Windows.Forms;
//Systems in use

//Pseudo-Code
//1. I am going to make a variable for all the things that need a variable
//   including captain Jack's share, the first mate's share, the crew's share,  
//   the number of pirates, the amount of gold found, and the pirate association
//   thing.
//2. I am going to make the equations for the shares of gold.
//3. I am going to make the button execute the code for the equations and display
//   that code in the respective text boxes.
//4. I am going to subtract the 3 gold per crew from the total gold found.
//5. I am going take out captain Jack's share, then the first mate's share.
//6. I am going to calculate how much gold each person gets after the initial split
//   among captain Jack and the first mate.
//7. The remaining gold goes to the PBF fund.

namespace Project2__CaptainJack_
{
    public partial class CaptainJacksGold : Form
    {
        public CaptainJacksGold()
        {
            InitializeComponent();
        }//End public Form1

        //method aboutToolStripMenuItem_Click
        //Purpose: Display message box that contains my info
        //Parameters: Object sending arguments and event arguments
        //Returns: Message box with my info given
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Creates message box to show my name, the class, and the project.
            MessageBox.Show("Hayden Hoki\nCS1400\nProject 2");
        }//End aboutToolStripMenuItem code

        //method exitToolStripMenuItem_Click
        //Purpose: Closes debugger
        //Parameters: Object sending arguments and event arguments
        //Returns: Termination of debugger
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Closes debugger on click
            this.Close();
        }//End exitToolStripMenuItem1 code

        //method buttonSplitGold_Click
        //Purpose: Calculate how the gold is to be distributed
        //Parameters: Object sending arguments and event arguments
        //Returns: Gold values that each person gets
        private void buttonSplitGold_Click(object sender, EventArgs e)
        {
            if (textBoxGold.Text == ""  )
                { }//End if statement
            else if (textBoxPirates.Text == "")
                { }//End else if statement
            else
            {
                //This is where I declare all of my variables and constants.
                const int funGold = 3;
                const int CAPTAIN_JACK_SHARE = 12;
                const int FIRST_MATE_SHARE = 8;
                const int SHARE = 100;
                int totalGold = int.Parse(textBoxGold.Text);
                int crew = int.Parse(textBoxPirates.Text) - 2;
                int gold = int.Parse(textBoxGold.Text);
                int allCrew = int.Parse(textBoxPirates.Text);

                //Equations for the code. Has code for the gold to update to it's
                //current amount after each person takes their share.
                int celebrationGold = (crew * funGold);
                gold = totalGold - celebrationGold;
                int captainJackShare = (gold * CAPTAIN_JACK_SHARE) / SHARE;
                gold = gold - captainJackShare;
                int firstMateShare = (gold * FIRST_MATE_SHARE) / SHARE;
                gold = gold - firstMateShare;

                //Code for the crew's gold share.
                double crewShare = 1 / (double)allCrew;
                double crewGold = gold * crewShare;

                //Gold = gold - the gold all the crew gets.
                gold = gold - ((int)crewGold * allCrew);

                //Remaining gold goes to the PBF.
                int PBF = gold;
                
                //Text boxes display respective numbers.
                textBoxCelebrate.Text = $"{celebrationGold}";
                textBoxCaptainJack.Text = $"{captainJackShare}";
                textBoxFirstMate.Text = $"{firstMateShare}";
                textBoxCrew.Text = $"{(int)crewGold}";
                textBoxPBF.Text = $"{PBF}";
            }//End main code
        }//End private void for button click
    }//End public partial class
}//End namespace
