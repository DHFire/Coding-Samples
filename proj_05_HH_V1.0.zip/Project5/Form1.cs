﻿using System;
using System.Windows.Forms;//Using systems

namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Declaring variables and constants
        int items;
        double price;
        const double sTax = .0745;
        const double lTax = .025;

        //buttonBuy_Click method
        //Purpose: To show user how much they have to pay after taxes and how much the taxes are.
        //Parameters: Object sending event arguments
        //Returns: Message box showing receipt.
        private void buttonBuy_Click(object sender, EventArgs e)
        {
            //Sets the text in the textboxes equal to a usable variable.
            items = int.Parse(textBoxItems.Text);
            price = double.Parse(textBoxPrice.Text);

            //Equations for the program.
            double netPrice = items * price;
            double stateTax = netPrice * sTax;
            double localTax = netPrice * lTax;
            double total = netPrice + stateTax + localTax;

            //Message box to display the user's information.
            MessageBox.Show($"Sales Ticket...\nQuantity: {items} units\nUnit Price: {price:c}\n-------------------------------------\nNet Price: {netPrice:c}\nState Sales Tax: {stateTax:c}\nLocal Sales Tax: {localTax:c}\nPlease pay: {total:c}");
        }

        //buttonClear_Click method
        //Purpose: To easily clear out all user input and effectively restart the program.
        //Parameters: Object sending event arguments.
        //Returns: Empty text boxes.
        private void buttonClear_Click(object sender, EventArgs e)
        {
            //Clears everything and sets everything else equal to zero.
            textBoxItems.Text = "";
            textBoxPrice.Text = "";
            items = 0;
            price = 0;
        }
    }
}
