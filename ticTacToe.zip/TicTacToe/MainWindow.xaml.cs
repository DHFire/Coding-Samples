﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TicTacToe
{
    public partial class MainWindow : Window
    {
        //All the variables being declared.
        int round;
        int win;
        int draw;

        //Random number generator
        Random randomStart = new Random();

        public MainWindow()
        {
            InitializeComponent();

            //Executes on start up.
            textBlockOutput.Text = "Enter names above then press 'Start Game'.";
        }

        //Happens when you click the start game button.
        private void buttonStartGame_Click(object sender, RoutedEventArgs e)
        {
            //If you have already played a game, this resets everything.
            win = 0;
            draw = 1;

            buttonGrid1.Background = Brushes.LightGray;
            buttonGrid2.Background = Brushes.LightGray;
            buttonGrid3.Background = Brushes.LightGray;
            buttonGrid4.Background = Brushes.LightGray;
            buttonGrid5.Background = Brushes.LightGray;
            buttonGrid6.Background = Brushes.LightGray;
            buttonGrid7.Background = Brushes.LightGray;
            buttonGrid8.Background = Brushes.LightGray;
            buttonGrid9.Background = Brushes.LightGray;

            buttonGrid1.Content = "";
            buttonGrid2.Content = "";
            buttonGrid3.Content = "";
            buttonGrid4.Content = "";
            buttonGrid5.Content = "";
            buttonGrid6.Content = "";
            buttonGrid7.Content = "";
            buttonGrid8.Content = "";
            buttonGrid9.Content = "";

            //Random player is selected to start off the game.
            round = randomStart.Next(0, 2);

            //I SWEAR THIS ISN'T CHEATING!!
            if (textBoxX.Text == "Hayden")
            {
                round = 0;
                textBlockOutput.Text = "It's " + textBoxX.Text + "'s turn.";
            }
            else if(textBoxO.Text == "Hayden")
            {
                round = 1;
                textBlockOutput.Text = "It's " + textBoxO.Text + "'s turn.";
            }
            //This is the program's way of telling the players whos turn it is.
            else
            {
                if (round == 0)
                {
                    textBlockOutput.Text = "It's " + textBoxX.Text + "'s turn.";
                }
                if (round == 1)
                {
                    textBlockOutput.Text = "It's " + textBoxO.Text + "'s turn.";
                }
            }
        }

        //Code to tell program who's turn it is and what to put in the button pressed.
        private void buttonClick_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;

            if (win == 0 && button.Content == "")
                {
                if (round % 2 == 0)
                    {
                    button.Content = "X";
                    textBlockOutput.Text = "It's " + textBoxO.Text + "'s turn.";
                    draw = draw + 1;
                    round = round + 1;
                }

                else if (round % 2 == 1)
                    {
                    button.Content = "O";
                    textBlockOutput.Text = "It's " + textBoxX.Text + "'s turn.";
                    draw = draw + 1;
                    round = round + 1;
                }

                else { }

                }
            //Win conditions.
            WinRound(buttonGrid1, buttonGrid2, buttonGrid3);
            WinRound(buttonGrid4, buttonGrid5, buttonGrid6);
            WinRound(buttonGrid7, buttonGrid8, buttonGrid9);
            WinRound(buttonGrid1, buttonGrid4, buttonGrid7);
            WinRound(buttonGrid2, buttonGrid5, buttonGrid8);
            WinRound(buttonGrid3, buttonGrid6, buttonGrid9);
            WinRound(buttonGrid1, buttonGrid5, buttonGrid9);
            WinRound(buttonGrid3, buttonGrid5, buttonGrid7);

            //Draw condition.
            if (draw == 10 && win == 0)
                {
                textBlockOutput.Text = "Draw! No one wins.";
                }
        }

        //Method for win condition. 
        private void WinRound(Button button1, Button button2, Button button3)
            {
            if (button1.Content == button2.Content && button2.Content == button3.Content && button1.Content != "")
                {
                button1.Background = Brushes.HotPink;
                button2.Background = Brushes.HotPink;
                button3.Background = Brushes.HotPink;

                win = 1;

                if (button1.Content == "X")
                    {
                    textBlockOutput.Text = "Congratulations, " + textBoxX.Text + " has won!!";
                    }
                if (button1.Content == "O")
                    {
                    textBlockOutput.Text = "Congratulations, " + textBoxO.Text + " has won!!";
                    }
                }
            }
    }
}